exports = (typeof window === 'undefined') ? global : window;

exports.stringsAnswers = {
  reduceString: function(str, amount) {
    var filtered = str.replace(/[^\w\s]|(.)\1/gi, "");
    return filtered;
  },
  wordWrap: function(str, cols) {

  },
  reverseString: function(str) {
     return    str.split("").reverse().join("");
  }
};
