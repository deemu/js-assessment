exports = (typeof window === 'undefined') ? global : window;

exports.countAnswers =  {
  count : function (start, end) {
        var cancel = false;
        var startCount = start
        for(startCount;end<start;startCount++){
          if(cancel){
            break;
          }
        }
        return startCount;
  }
};
