# Change Log

## 0.3.0

- Remove jquery, backbone, underscore, mocha, and chai as local libraries
- Remove RequireJS
  - node deps use native `require()`
  - browser deps are `script` tags

## 0.2.0

- Convert app from Express to using serve-static
- Replace bin/server with a `grunt connect` task and `npm start` script
- Update dependencies

## < 0.1.0

- Initial commits. Hello World!
